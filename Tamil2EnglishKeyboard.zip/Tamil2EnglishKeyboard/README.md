# Tamil2English Keyboard (Android IME, Kotlin)

Tap **Start**, speak Tamil, and the **English translation is typed into the focused text field**
(WhatsApp, Gmail, Instagram, browser, notes...). It is a real Android keyboard (an
`InputMethodService`). It does **not** use Accessibility Service or ask for full device control.

## How it works

| Part | File | What it does |
|---|---|---|
| Keyboard | `Tamil2EnglishIME.kt` | Keyboard UI, Start / Stop / Clear, ordered insertion with `commitText` |
| Speech | `SpeechController.kt` | `SpeechRecognizer` with `ta-IN`, instant restart, duplicate protection |
| Translation | `Translator.kt` | Free MyMemory API (same as the web app) |
| Setup screen | `MainActivity.kt` | Mic permission, enable keyboard, test field |
| Keyboard definition | `res/xml/method.xml`, `AndroidManifest.xml` | Registers the IME |

Duplicate / lost-word protection:
- Each listening session has an id; callbacks from old sessions are ignored.
- A session can deliver only one final result. Interim text is display-only.
- When a session ends without a final result, the last interim text is kept (not lost).
- Text that repeats, or only extends, the previous sentence (within 2.5 s) is not inserted twice.
- Each Tamil sentence is translated once (cached) and inserted in the order it was spoken.

Buttons: **Start** / **Stop** (microphone), **Clear** (clears previews and removes the text this keyboard just typed,
only if you have not edited it), **globe** (switch keyboard), **Space**, **Backspace** (hold to repeat), **Enter**.

---

## Build the APK from your phone (no computer): GitHub Actions

GitHub gives free build minutes on its servers. You only need a browser.

1. In Chrome on your phone, open **github.com** and create a free account. Turn on
   **Desktop site** (Chrome menu) so the editor works properly.
2. Tap **+ > New repository**. Name it `Tamil2EnglishKeyboard`. Tick **Add a README file**. Create it.
3. **Add file > Upload files** and choose **`Tamil2EnglishKeyboard.zip`** (the single zip). Tap **Commit changes**.
   Do not unzip it. The workflow unzips it for you.
4. **Add file > Create new file**. In the name box type exactly:
   `.github/workflows/build-apk.yml`
   (typing the `/` creates the folders). Paste the contents of `build-apk.yml`. Tap **Commit changes**.
5. Open the **Actions** tab. A run called *Build Tamil2English Keyboard APK* starts (about 5 to 8 minutes).
   If it does not start, open it in the left list and tap **Run workflow**.
6. When it shows a green tick, open the repository's **Releases** (right side or `/releases`) and tap
   **Tamil2English-Keyboard.apk** to download it. (It is also in the run page under **Artifacts**.)
7. If the run fails (red cross), open it, tap the failed step, and copy the last 30 lines of the log.
   Send them to Claude to get a fix.

## Install and enable

1. Open the downloaded APK. Android asks you to allow **Install unknown apps** for Chrome (or Files). Allow it.
   - Samsung: if install is blocked, turn off **Settings > Security and privacy > Auto Blocker**.
   - If Play Protect says "unsafe", tap **More details > Install anyway** (the app is signed with a debug key).
2. Open **Tamil2English Keyboard**:
   1. **Allow microphone**
   2. **Enable the keyboard** (turn on Tamil2English Keyboard; accept the standard Android warning)
   3. **Switch to this keyboard**
3. In WhatsApp / Gmail / Instagram tap a text box, show the keyboard, choose **Tamil2English Keyboard**
   with the globe button or the keyboard icon at the bottom right, tap **Start**, and speak Tamil.

## Limitations (please read)

- **Not truly continuous.** Android's `SpeechRecognizer` listens in short sessions. The keyboard restarts it in
  about 40 ms, but a word spoken exactly at the restart can still be missed, and some phones play a small
  "beep" at each restart. Speak in sentences with short pauses.
- **Needs the Google speech service** (Google app / Speech Services) and, normally, **internet** for Tamil.
  If Tamil is unavailable, open the Google app > Settings > Voice > Languages and download Tamil.
- **Translation quality** is machine quality. MyMemory's free tier has a daily character limit.
- **Voice-only keyboard.** It has Space, Backspace and Enter, but no typing layout. Use the globe key to switch
  to Gboard or Samsung Keyboard for typing.
- **Some fields refuse voice typing:** password fields (disabled on purpose), and some banking or secure apps.
- **Keyboard hidden or field changed = listening stops** (so text never lands in the wrong field).
- **Microphone permission is requested in the app screen**, not in the keyboard (Android does not allow dialogs
  from a keyboard).
- **Debug APK:** signed with a debug key, fine for personal use, not for the Play Store.
- **Phone-only workflow:** Android Studio cannot run on a phone, so you cannot debug or view logcat.
  Edits are done in the GitHub web editor and each rebuild takes a few minutes.

## Open in Android Studio (when you have a computer)

Open the `Tamil2EnglishKeyboard` folder. If Android Studio asks for the Gradle wrapper, run
`gradle wrapper --gradle-version 8.7` once (or let Studio create it). Build with *Build > Build APK(s)*.

## Change things

- Language: `SpeechController.buildIntent()` (`ta-IN`) and `Translator.kt` (`langpair=ta|en`).
- Translation provider: replace `Translator.tamilToEnglish()`.
- Colors and layout: `res/layout/keyboard_view.xml`.
