package com.tamil2english.keyboard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Wraps Android's SpeechRecognizer (Tamil, ta-IN) and gives the keyboard clean results:
 *
 *  - Android's recognizer is not truly continuous, so we listen in short "sessions" and
 *    restart immediately after each one (the restart happens in ~40 ms).
 *  - Every session gets its own id. Callbacks from an older session are ignored, and each
 *    session can deliver only ONE final result, so the same speech is never reported twice.
 *  - Interim ("partial") text is only for display. Only confirmed text goes to onFinal().
 *  - If a session ends without a final result (silence, timeout, error, Stop), the last partial
 *    text is promoted to a confirmed result, so words are not lost at restarts.
 *  - A final safety check drops text that repeats the previous sentence, or only extends it.
 *
 * All calls and callbacks happen on the main thread.
 */
class SpeechController(
    private val context: Context,
    private val callback: Callback
) {

    enum class StopReason { USER, NEEDS_PERMISSION, ERROR }

    interface Callback {
        /** Microphone is open (called at the start of every listening session). */
        fun onListening()

        /** Live, unconfirmed text. Empty string means "clear the live text". */
        fun onPartial(text: String)

        /** A confirmed piece of Tamil text. Never duplicated. */
        fun onFinal(text: String)

        /** Stop was requested; waiting for the last result. */
        fun onStopping()

        /** Fully stopped. message is set when the reason is an error. */
        fun onStopped(reason: StopReason, message: String?)
    }

    private companion object {
        const val RESTART_DELAY_MS = 40L
        const val RETRY_DELAY_MS = 400L
        const val STOP_TIMEOUT_MS = 1800L
        const val DUPLICATE_WINDOW_MS = 2500L
        const val MAX_FAILURES = 4
        const val ERROR_SERVER_DISCONNECTED = 11   // API 31+
        const val ERROR_LANGUAGE_NOT_SUPPORTED = 12 // API 31+
        const val ERROR_LANGUAGE_UNAVAILABLE = 13   // API 31+
    }

    private val main = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var wanted = false        // user wants to keep listening
    private var stopping = false      // Stop pressed, waiting for the last result
    private var sessionId = 0
    private var handled = false       // current session already produced its result
    private var lastPartial = ""
    private var failures = 0

    private var lastCommitted = ""
    private var lastCommittedAt = 0L

    val isActive: Boolean get() = wanted || stopping

    // ---------------------------------------------------------------- public API

    fun start() {
        if (isActive) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            callback.onStopped(
                StopReason.ERROR,
                "No speech recognition service found. Install or enable the Google app."
            )
            return
        }
        if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            callback.onStopped(StopReason.NEEDS_PERMISSION, "Microphone permission is needed.")
            return
        }
        wanted = true
        stopping = false
        failures = 0
        beginSession(0L)
    }

    /** Stop listening but keep (and deliver) whatever was already heard. */
    fun stop() {
        if (!isActive || stopping) return
        wanted = false
        stopping = true
        callback.onStopping()

        val rec = recognizer
        if (rec == null || handled) {
            // Between two sessions: nothing is in flight, so we can finish right away.
            completeStop(StopReason.USER, null)
            return
        }
        val id = sessionId
        try {
            rec.stopListening()   // the service answers with onResults() or onError()
        } catch (e: Exception) {
            // handled by the safety net below
        }
        main.postDelayed({
            if (stopping && id == sessionId) {
                handled = true
                commit(lastPartial)
                completeStop(StopReason.USER, null)
            }
        }, STOP_TIMEOUT_MS)
    }

    /** Hard stop without delivering anything (keyboard hidden / field changed). */
    fun abort() {
        if (!isActive && recognizer == null) return
        wanted = false
        stopping = false
        sessionId++
        destroyRecognizer()
        callback.onPartial("")
        callback.onStopped(StopReason.USER, null)
    }

    /** Forget the previous sentence (used by Clear, so it can be said again). */
    fun clearHistory() {
        lastCommitted = ""
        lastCommittedAt = 0L
    }

    /** Free everything. No callbacks are sent. */
    fun release() {
        wanted = false
        stopping = false
        sessionId++
        destroyRecognizer()
        main.removeCallbacksAndMessages(null)
    }

    // ---------------------------------------------------------------- sessions

    private fun beginSession(delayMs: Long) {
        val id = ++sessionId
        main.postDelayed({
            if (id == sessionId && wanted) startRecognizer(id)
        }, delayMs)
    }

    private fun startRecognizer(id: Int) {
        destroyRecognizer()
        handled = false
        lastPartial = ""
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(context)
            r.setRecognitionListener(SessionListener(id))
            recognizer = r
            r.startListening(buildIntent())
        } catch (e: Exception) {
            fail(StopReason.ERROR, "Could not start speech recognition: ${e.message}")
        }
    }

    private fun destroyRecognizer() {
        val r = recognizer ?: return
        recognizer = null
        try {
            r.cancel()
            r.destroy()
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun buildIntent(): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            // Hints (some recognizers ignore them): finish a sentence after a short pause.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        }

    private inner class SessionListener(private val id: Int) : RecognitionListener {
        private fun stale() = id != sessionId

        override fun onReadyForSpeech(params: Bundle?) {
            if (!stale()) callback.onListening()
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (stale() || handled) return
            val text = firstResult(partialResults) ?: return
            lastPartial = text
            callback.onPartial(text)
        }

        override fun onResults(results: Bundle?) {
            if (stale() || handled) return
            handled = true
            finishSession(firstResult(results) ?: lastPartial)
        }

        override fun onError(error: Int) {
            if (stale() || handled) return
            handled = true
            handleError(error)
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun firstResult(bundle: Bundle?): String? =
        bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            ?.takeIf { it.isNotBlank() }

    /** A session ended normally (or with silence). Deliver its text, then listen again or finish. */
    private fun finishSession(text: String) {
        failures = 0
        commit(text)
        callback.onPartial("")
        if (wanted) beginSession(RESTART_DELAY_MS) else completeStop(StopReason.USER, null)
    }

    private fun handleError(error: Int) {
        when (error) {
            SpeechRecognizer.ERROR_NO_MATCH,
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                finishSession(lastPartial)   // silence: keep any heard words, then listen again

            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                fail(StopReason.NEEDS_PERMISSION, "Microphone permission is needed.")

            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                fail(
                    StopReason.ERROR,
                    "No internet. Tamil recognition needs a connection (or an offline Tamil pack)."
                )

            ERROR_LANGUAGE_NOT_SUPPORTED,
            ERROR_LANGUAGE_UNAVAILABLE ->
                fail(
                    StopReason.ERROR,
                    "Tamil (ta-IN) voice typing is not available. In the Google app, download Tamil."
                )

            SpeechRecognizer.ERROR_AUDIO ->
                fail(StopReason.ERROR, "Microphone problem. Close other apps that use the mic.")

            else -> {   // busy, client, server, server disconnected ...
                commit(lastPartial)
                failures++
                when {
                    failures > MAX_FAILURES ->
                        fail(StopReason.ERROR, "Speech service keeps failing (code $error). Try again.")
                    wanted -> beginSession(RETRY_DELAY_MS)
                    else -> completeStop(StopReason.USER, null)
                }
            }
        }
    }

    private fun fail(reason: StopReason, message: String) {
        commit(lastPartial)   // do not lose words that were already heard
        completeStop(reason, message)
    }

    private fun completeStop(reason: StopReason, message: String?) {
        wanted = false
        stopping = false
        sessionId++            // anything still arriving from the old recognizer is ignored
        destroyRecognizer()
        callback.onPartial("")
        callback.onStopped(reason, message)
    }

    // ---------------------------------------------------------------- duplicate protection

    /**
     * Sends confirmed text to the keyboard, but never the same speech twice:
     *  - identical to the previous sentence (or a shorter beginning of it) -> dropped
     *  - the previous sentence plus more words -> only the new words are sent
     * Both rules apply only within a short time window, so a deliberate repeat later is kept.
     */
    private fun commit(raw: String) {
        val text = raw.trim().replace(Regex("\\s+"), " ")
        if (text.isEmpty()) return

        val now = SystemClock.elapsedRealtime()
        var toEmit = text
        if (lastCommitted.isNotEmpty() && now - lastCommittedAt < DUPLICATE_WINDOW_MS) {
            if (text == lastCommitted || lastCommitted.startsWith("$text ")) return
            if (text.startsWith("$lastCommitted ")) {
                toEmit = text.substring(lastCommitted.length).trim()
            }
        }
        lastCommitted = text
        lastCommittedAt = now
        if (toEmit.isNotEmpty()) callback.onFinal(toEmit)
    }
}
