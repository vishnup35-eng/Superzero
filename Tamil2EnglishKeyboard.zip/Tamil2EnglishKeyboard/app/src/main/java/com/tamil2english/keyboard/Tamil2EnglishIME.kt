package com.tamil2english.keyboard

import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Tamil2English Keyboard (Input Method Editor).
 *
 * Tap Start, speak Tamil, and the English translation is typed into whatever text field
 * is focused (WhatsApp, Gmail, Instagram, browser, notes ...) through the standard
 * InputConnection. No Accessibility Service, no overlay, no extra device access.
 */
class Tamil2EnglishIME : InputMethodService(), SpeechController.Callback {

    private val main = Handler(Looper.getMainLooper())
    private val executor: ExecutorService = Executors.newFixedThreadPool(3)
    private lateinit var speech: SpeechController

    private var statusView: TextView? = null
    private var tamilView: TextView? = null
    private var englishView: TextView? = null
    private var startBtn: Button? = null
    private var stopBtn: Button? = null

    private var passwordField = false
    private var lastFinalTamil = ""

    /** Exactly what voice typing has inserted since the last Clear / manual key (used by Clear). */
    private val voiceInserted = StringBuilder()

    // Translation pipeline: translations run in parallel but are inserted strictly in speaking order.
    private var epoch = 0                  // bumped by Clear / field change: late results are dropped
    private var nextSeq = 0                // sequence number given to the next sentence
    private var nextToInsert = 0           // sequence number that may be inserted next
    private val ready = HashMap<Int, String?>()          // seq -> English (null = failed)
    private val cache = HashMap<String, String>()        // Tamil sentence -> English (never translate twice)

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        speech = SpeechController(this, this)
    }

    override fun onCreateInputView(): View {
        val v = layoutInflater.inflate(R.layout.keyboard_view, null)
        statusView = v.findViewById<TextView>(R.id.status)
        tamilView = v.findViewById<TextView>(R.id.tamilText)
        englishView = v.findViewById<TextView>(R.id.englishText)
        startBtn = v.findViewById<Button>(R.id.btnStart)
        stopBtn = v.findViewById<Button>(R.id.btnStop)

        startBtn?.setOnClickListener { onStartClicked() }
        stopBtn?.setOnClickListener {
            speech.stop()
            refreshUi()
        }
        v.findViewById<Button>(R.id.btnClear).setOnClickListener { onClearClicked() }
        v.findViewById<Button>(R.id.btnSwitch).setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        v.findViewById<Button>(R.id.btnSpace).setOnClickListener {
            voiceInserted.setLength(0)
            currentInputConnection?.commitText(" ", 1)
        }
        v.findViewById<Button>(R.id.btnEnter).setOnClickListener {
            voiceInserted.setLength(0)
            pressEnter()
        }
        setupBackspace(v.findViewById<Button>(R.id.btnBackspace))

        refreshUi()
        return v
    }

    /** No fullscreen keyboard in landscape: keep the app visible. */
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        passwordField = info?.let { isPasswordField(it) } ?: false
        if (!restarting) voiceInserted.setLength(0)
        when {
            passwordField -> setStatus("Voice typing is turned off in password fields.")
            !speech.isActive -> setStatus("Ready. Tap Start and speak Tamil.")
        }
        refreshUi()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        // Keyboard hidden or another field focused: stop the mic and drop pending translations,
        // so nothing from the old field can land in a new one.
        speech.abort()
        resetPipeline()
        voiceInserted.setLength(0)
        super.onFinishInputView(finishingInput)
    }

    override fun onDestroy() {
        speech.release()
        executor.shutdownNow()
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ buttons

    private fun onStartClicked() {
        if (passwordField) {
            setStatus("Voice typing is turned off in password fields.")
            return
        }
        speech.start()
        refreshUi()
    }

    /**
     * Clear: wipes the previews and removes the text this keyboard typed by voice,
     * but only if it is still exactly where we left it (it never deletes text you edited).
     */
    private fun onClearClicked() {
        resetPipeline()           // translations still in flight are discarded
        speech.clearHistory()

        var message = "Cleared."
        val ic = currentInputConnection
        if (ic != null && voiceInserted.isNotEmpty()) {
            val inserted = voiceInserted.toString()
            val before = ic.getTextBeforeCursor(inserted.length, 0)?.toString()
            if (before == inserted) {
                ic.deleteSurroundingText(inserted.length, 0)
            } else {
                message = "Cleared. The text was edited, so the field was left unchanged."
            }
        }
        voiceInserted.setLength(0)
        lastFinalTamil = ""
        tamilView?.text = ""
        englishView?.text = ""
        setStatus(if (speech.isActive) "$message Still listening." else message)
    }

    private fun pressEnter() {
        val options = currentInputEditorInfo?.imeOptions ?: 0
        val action = options and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (options and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            currentInputConnection?.performEditorAction(action)   // Send / Search / Go / Done ...
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)           // plain new line
        }
    }

    @Suppress("ClickableViewAccessibility")
    private fun setupBackspace(btn: Button) {
        val repeat = object : Runnable {
            override fun run() {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                main.postDelayed(this, 50)
            }
        }
        btn.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    voiceInserted.setLength(0)
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                    main.postDelayed(repeat, 400)    // hold to keep deleting
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    main.removeCallbacks(repeat)
                }
            }
            true
        }
    }

    // ------------------------------------------------------------------ SpeechController.Callback

    override fun onListening() {
        setStatus("● Listening... speak Tamil")
        refreshUi()
    }

    override fun onPartial(text: String) {
        // Interim text is display-only; it is never inserted.
        tamilView?.text = if (text.isNotBlank()) text else lastFinalTamil
    }

    override fun onFinal(text: String) {
        lastFinalTamil = text
        tamilView?.text = text
        enqueueTranslation(text)
    }

    override fun onStopping() {
        setStatus("Finishing...")
        refreshUi()
    }

    override fun onStopped(reason: SpeechController.StopReason, message: String?) {
        when (reason) {
            SpeechController.StopReason.USER -> setStatus("Stopped. Tap Start to continue.")
            SpeechController.StopReason.ERROR -> setStatus(message ?: "Speech recognition stopped.")
            SpeechController.StopReason.NEEDS_PERMISSION -> {
                setStatus("Microphone permission needed. Opening the app screen...")
                try {
                    startActivity(
                        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    setStatus("Open the Tamil2English Keyboard app and tap \"Allow microphone\".")
                }
            }
        }
        refreshUi()
    }

    // ------------------------------------------------------------------ translation + insertion

    private fun enqueueTranslation(tamil: String) {
        val seq = nextSeq++
        val myEpoch = epoch

        val cached = cache[tamil]
        if (cached != null) {                     // same sentence already translated
            deliver(myEpoch, seq, cached)
            return
        }
        executor.execute {
            val english = Translator.tamilToEnglish(tamil)
            main.post {
                if (english != null) cache[tamil] = english
                deliver(myEpoch, seq, english)
            }
        }
    }

    /** Called on the main thread when sentence [seq] has its translation (null = failed). */
    private fun deliver(forEpoch: Int, seq: Int, english: String?) {
        if (forEpoch != epoch) return            // Clear or field change happened meanwhile
        ready[seq] = english
        while (ready.containsKey(nextToInsert)) {      // insert strictly in speaking order
            val text = ready.remove(nextToInsert)
            nextToInsert++
            if (text == null) {
                setStatus("Translation failed. Check your internet connection.")
            } else {
                insertEnglish(text)
            }
        }
    }

    private fun insertEnglish(english: String) {
        var out = english.trim()
        if (out.isEmpty()) return
        val ic = currentInputConnection
        if (ic == null) {
            setStatus("No text field is selected.")
            return
        }
        ic.beginBatchEdit()
        val prev = ic.getTextBeforeCursor(1, 0)
        if (!prev.isNullOrEmpty() && !prev[0].isWhitespace()) out = " $out"   // space between sentences
        ic.commitText(out, 1)
        ic.endBatchEdit()

        voiceInserted.append(out)
        englishView?.text = english.trim()
    }

    private fun resetPipeline() {
        epoch++
        nextSeq = 0
        nextToInsert = 0
        ready.clear()
    }

    // ------------------------------------------------------------------ helpers

    private fun setStatus(text: String) {
        statusView?.text = text
    }

    private fun refreshUi() {
        val active = speech.isActive
        startBtn?.apply {
            isEnabled = !active && !passwordField
            alpha = if (isEnabled) 1f else 0.4f
        }
        stopBtn?.apply {
            isEnabled = active
            alpha = if (isEnabled) 1f else 0.4f
        }
    }

    private fun isPasswordField(info: EditorInfo): Boolean {
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        return when (cls) {
            InputType.TYPE_CLASS_TEXT ->
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        }
    }
}
