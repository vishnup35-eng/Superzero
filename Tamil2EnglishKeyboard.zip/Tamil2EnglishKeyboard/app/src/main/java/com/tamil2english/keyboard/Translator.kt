package com.tamil2english.keyboard

import android.text.Html
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Tamil -> English using the free MyMemory service (same service as the web app).
 * All calls are blocking: run them on a background thread.
 */
object Translator {
    private const val ENDPOINT = "https://api.mymemory.translated.net/get"
    private const val MAX_CHARS = 450   // MyMemory limit is 500 characters per request

    /** Returns the English text, or null if the translation failed. */
    fun tamilToEnglish(text: String): String? {
        if (text.length <= MAX_CHARS) return translateChunk(text)
        val out = StringBuilder()
        for (part in splitForLimit(text)) {
            val t = translateChunk(part) ?: return null
            if (out.isNotEmpty()) out.append(' ')
            out.append(t)
        }
        return out.toString()
    }

    private fun splitForLimit(text: String): List<String> {
        val parts = mutableListOf<String>()
        val cur = StringBuilder()
        for (word in text.split(' ')) {
            if (cur.isNotEmpty() && cur.length + 1 + word.length > MAX_CHARS) {
                parts.add(cur.toString())
                cur.setLength(0)
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(word)
        }
        if (cur.isNotEmpty()) parts.add(cur.toString())
        return parts
    }

    private fun translateChunk(text: String): String? {
        var conn: HttpURLConnection? = null
        try {
            val q = URLEncoder.encode(text, "UTF-8")
            conn = URL("$ENDPOINT?q=$q&langpair=ta%7Cen").openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.requestMethod = "GET"
            if (conn.responseCode != 200) return null

            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val json = JSONObject(body)
            val status = json.opt("responseStatus")?.toString()?.toIntOrNull() ?: 200
            if (status != 200) return null

            val raw = json.optJSONObject("responseData")?.optString("translatedText") ?: return null
            if (raw.isBlank() || raw.startsWith("MYMEMORY WARNING", ignoreCase = true)) return null

            // MyMemory sometimes returns HTML entities such as &#39;
            return Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY).toString().trim()
        } catch (e: Exception) {
            return null
        } finally {
            conn?.disconnect()
        }
    }
}
